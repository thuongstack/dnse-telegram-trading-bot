import asyncio
import json

from datetime import datetime
from zoneinfo import ZoneInfo
import requests
import subprocess
import sys

from dnse import DNSEClient
# ==================== CẤU HÌNH ====================


API_KEY_ENC = "api_key.enc"
API_SECRET_ENC = "api_secret.enc"
#TOKEN_TELEGRAM_ENC = "token_telegram.enc"
TOKEN_ZALO_ENC = "token_zalo.enc"

# ================= Giải mã API =================

def decrypt_file(encrypted_file: str) -> str:
    """Giải mã file .enc bằng OpenSSL"""
    try:
        result = subprocess.run(
            [
                "openssl", "enc", "-aes-256-cbc", "-d", "-pbkdf2",
                "-in", encrypted_file,
                "-pass", f"file:api.key"
            ],
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout.strip()
    

    except subprocess.CalledProcessError:
        print(f"❌ Lỗi giải mã {encrypted_file}")
        sys.exit(1)

    except FileNotFoundError:
        print("❌ Lỗi: OpenSSL chưa được cài đặt")
        sys.exit(1)

    
print("🔄 Đang giải mã thông tin...")


API_KEY = decrypt_file(API_KEY_ENC)
API_SECRET = decrypt_file(API_SECRET_ENC)

BOT_ZALO = decrypt_file(TOKEN_ZALO_ENC)


print("✅ Giải mã thành công!")


BASE_URL = "https://openapi.dnse.com.vn"

ZALO_CHAT_ID = "fa6ecd98b2cc5b9202dd"
ACCOUNT_NO = "0001250364"


VN_TZ = ZoneInfo("Asia/Ho_Chi_Minh")

WATCHER_DAYS = [0,1,2,3,4,5]
WATCHER_START = (0, 30)
WATCHER_END   = (23, 10)

# ====== DNSE CLIENT CHỈ THEO DÕI ======
client = DNSEClient(
    api_key=API_KEY,
    api_secret=API_SECRET,
    base_url=BASE_URL,
)

last_state = {}

# ======================

def is_watcher_time():
    now = datetime.now(VN_TZ)
    weekday = now.weekday()

    if weekday not in WATCHER_DAYS:
        return False

    start_time = now.replace(
        hour=WATCHER_START[0],
        minute=WATCHER_START[1],
        second=0,
        microsecond=0
    )

    end_time = now.replace(
        hour=WATCHER_END[0],
        minute=WATCHER_END[1],
        second=59,
        microsecond=999999
    )

    return start_time <= now <= end_time


def send_zalo(text):
    try:
        url = f"https://bot-api.zaloplatforms.com/bot{BOT_ZALO}/sendMessage"
        payload = {
            "chat_id": ZALO_CHAT_ID,
            "text": text
        }
        requests.post(url, json=payload, timeout=10)
    except Exception as e:
        print("Zalo lỗi:", e)


# ================= THEO DÕI =================

async def watch_orders():
    print("🟢 Zalo watcher 24/7 đã chạy")

    last_state = {}

    while True:

        if not is_watcher_time():

            await asyncio.sleep(3)
            print("🟢 Zalo ngoài giờ")
            continue

        try:
            status, body = client.get_orders(
                account_no=ACCOUNT_NO,
                market_type="STOCK",
                dry_run=False
            )

            if status != 200:
                await asyncio.sleep(3)
                continue

            if isinstance(body, str):
                body = json.loads(body)

            orders = body.get("orders", [])

            for o in orders:

                order_id = o.get("id")
                symbol = o.get("symbol")
                side = o.get("side")
                status_text = (o.get("orderStatus") or "").upper()

                quantity = o.get("quantity", 0)
                fill_qty = o.get("fillQuantity", 0)
                avg_price = o.get("averagePrice", 0)
                last_price = o.get("lastPrice", 0)
                canceled_qty = o.get("canceledQuantity", 0)

                icon = "🟢" if side == "NB" else "🔴"

                prev = last_state.get(order_id, {})
                prev_fill = prev.get("fill", 0)
                prev_canceled = prev.get("canceled", 0)

                # ===== LẦN ĐẦU CHỈ LƯU =====
                if order_id not in last_state:
                    last_state[order_id] = {
                        "fill": fill_qty,
                        "canceled": canceled_qty
                    }
                    continue

                msg = None

                # ===== KHỚP THÊM =====
                if fill_qty > prev_fill:

                    if fill_qty < quantity:
                        msg = (
                            f"⚡ KHỚP THÊM\n"
                            f"{icon} {symbol}\n"
                            f"Đã khớp: {fill_qty:,}/{quantity:,}\n"
                            f"Giá TB: {avg_price:,.0f}"
                        )

                    elif fill_qty == quantity:
                        msg = (
                            f"🎯 KHỚP TOÀN BỘ\n"
                            f"{icon} {symbol}\n"
                            f"KL: {quantity:,}\n"
                            f"Giá TB: {avg_price:,.0f}"
                        )

                # ===== HỦY (THEO canceledQuantity) =====
                elif canceled_qty > prev_canceled:

                    msg = (
                        f"❌ ĐÃ HỦY LỆNH\n"
                        f"{icon} {symbol}\n"
                        f"Khớp: {fill_qty:,}\n"
                        f"Hủy: {canceled_qty:,}"
                    )

                if msg:
                    send_zalo(msg)

                last_state[order_id] = {
                    "fill": fill_qty,
                    "canceled": canceled_qty
                }

            await asyncio.sleep(3)

        except Exception as e:
            print("❌ Lỗi watcher:", e)
            await asyncio.sleep(5)


if __name__ == "__main__":
    asyncio.run(watch_orders())