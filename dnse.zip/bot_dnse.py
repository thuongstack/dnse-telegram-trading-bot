import json
import asyncio
import sys
import os
import subprocess
import time
import requests
import re
import pytz
import time
import psutil

from unidecode import unidecode
from telegram import InlineKeyboardButton, InlineKeyboardMarkup


from telegram import Update
from telegram.ext import (
    CallbackQueryHandler,
    ApplicationBuilder,
    CommandHandler,
    MessageHandler,
    ContextTypes,
    filters,
)

from telegram.request import HTTPXRequest
from dotenv import load_dotenv
from datetime import datetime
from zoneinfo import ZoneInfo






from dnse import DNSEClient
cancel_locks = {}

# ==================== CẤU HÌNH ====================

BOT_TELEGRAM_ENC = "token_telegram.enc"
API_KEY_ENC = "api_key.enc"
API_SECRET_ENC = "api_secret.enc"


# ================= Giải mã API =================

def decrypt_file(encrypted_file: str) -> str:
    """Giải mã file .enc bằng OpenSSL"""
    try:
        result = subprocess.run(
            [
                "openssl", "enc", "-aes-256-cbc", "-d", "-pbkdf2",
                "-in", encrypted_file,
                "-pass", f"file:api.key"
            ],
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout.strip()
    

    except subprocess.CalledProcessError:
        print(f"❌ Lỗi giải mã {encrypted_file}")
        sys.exit(1)

    except FileNotFoundError:
        print("❌ Lỗi: OpenSSL chưa được cài đặt")
        sys.exit(1)

    
print("🔄 Đang giải mã thông tin...")

BOT_TELEGRAM = decrypt_file(BOT_TELEGRAM_ENC)
API_KEY = decrypt_file(API_KEY_ENC)
API_SECRET = decrypt_file(API_SECRET_ENC)
    
print("✅ Giải mã thành công!")
    

AUTHORIZED_CHAT_ID = 7274863226  # THAY BẰNG ID CỦA BẠN

WATCHER_ENABLED = True  # True = bật theo dõi | False = tắt

BASE_URL = "https://openapi.dnse.com.vn"


# ================= DNSE CLIENT =================



client = DNSEClient(
    api_key=API_KEY,
    api_secret=API_SECRET,
    base_url=BASE_URL,
)


account_no = None
trading_token = None
current_otp_type = None

pending_orders = {}


# ================= CẤU HÌNH TÙY GIỜ WATCHER =================

WATCHER_DAYS = [0,1,2,3,4]  
# 0=Thứ 2 ... 6=Chủ nhật
# Ví dụ chỉ chạy Thứ 2-6

WATCHER_START = (8, 00)   # tùy chỉnh giờ bắt đầu ví dụ: 08:30
WATCHER_END   = (15, 00) # tùy chỉnh giờ kết thúc ví dụ: 15:00

VN_TZ = ZoneInfo("Asia/Ho_Chi_Minh")


def is_watcher_time():
    if not WATCHER_ENABLED:
        return False

    now = datetime.now(VN_TZ)
    weekday = now.weekday()

    if weekday not in WATCHER_DAYS:
        return False

    start_time = now.replace(
        hour=WATCHER_START[0],
        minute=WATCHER_START[1],
        second=0,
        microsecond=0
    )
    end_time = now.replace(
        hour=WATCHER_END[0],
        minute=WATCHER_END[1],
        second=59,
        microsecond=999999
    )

    return start_time <= now <= end_time

# =========================
# CẢNH BÁO ĐA MỐC DANH MỤC
# =========================

PROFIT_LEVELS = [10, 20, 30]     # mốc lãi %
LOSS_LEVELS   = [-5, -10, -20]   # mốc lỗ %

deal_alert_state = {}   # lưu mốc đã báo cho từng mã



async def safe_send(update, text, disable_notification=False):
    MAX_LEN = 4000
    for i in range(0, len(text), MAX_LEN):
        await update.message.reply_text(
            text[i:i+MAX_LEN],
            disable_notification=disable_notification
        )


# ================= HELPER =================
def authorized(update: Update):
    return update.effective_chat.id == AUTHORIZED_CHAT_ID

async def request_otp_email(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.args = ["email"]
    await request_otp(update, context)


async def request_otp_smart(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.args = ["smart"]
    await request_otp(update, context)


# =================Lấy mã Email OTP hoặc Smart OTP =================
async def request_otp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global current_otp_type

    if not authorized(update):
        return

    if len(context.args) != 1:
        await update.message.reply_text(
            "Dùng:\n"
            "/otp_email  → nhận OTP qua email\n"
            "/otp_smart  → dùng Smart OTP trong app",
            disable_notification=True
        )
        return

    otp_mode = context.args[0].lower()

    # ===== EMAIL OTP =====
    if otp_mode == "email":
        current_otp_type = "email_otp"

        loop = asyncio.get_running_loop()
        status, body = await loop.run_in_executor(
            None,
            lambda: client.send_email_otp(dry_run=False)
        )

        if status == 200:
            await update.message.reply_text(
                "📧 OTP đã gửi về email.\n"
                "Nhập: /verify 123456",
                disable_notification=True 
            )

        else:
            await update.message.reply_text(
                f"Lỗi gửi OTP:\nEmail OTP chưa đăng ký cho tài khoản\n",
                disable_notification=True                           
            )
            

    # ===== SMART OTP =====
    elif otp_mode == "smart":
        current_otp_type = "smart_otp"

        await update.message.reply_text(
            "🔐 Mở app DNSE → lấy Smart OTP\n"
            "Nhập: /verify 123456 (trong 30 giây)",
            disable_notification=True
        )

    else:
        await update.message.reply_text("Lỗi gửi OTP: Smart OTP chưa đăng ký cho tài khoản\n",
            disable_notification=True 
        )

      #====== Nhập mã OTP ======
async def verify_otp(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global trading_token, account_no, current_otp_type

    if not authorized(update):
        return

    if not current_otp_type:
        await update.message.reply_text("Chưa chọn loại OTP. Dùng /otp email hoặc /otp smart",
            disable_notification=True                            
        )
        return

    if len(context.args) != 1:
        await update.message.reply_text("Sai cú pháp: /verify 123456",
            disable_notification=True                           
        )
        return

    otp_code = context.args[0]
    loop = asyncio.get_running_loop()

    status, body = await loop.run_in_executor(
        None,
        lambda: client.create_trading_token(
            otp_type=current_otp_type,
            passcode=otp_code,
            dry_run=False
        )
    )

    

    if status != 200:
        await update.message.reply_text(f"Lỗi tạo trading token:\n{body}",
            disable_notification=True                           
        )

        return

    if isinstance(body, str):
        body = json.loads(body)

    trading_token = body.get("tradingToken")

    if not trading_token:
        await update.message.reply_text("Không nhận được tradingToken.",
            disable_notification=True                              
        )
        return

    client.trading_token = trading_token

    # ===== Lấy tài khoản =====
    acc_status, acc_body = await loop.run_in_executor(
        None,
        lambda: client.get_accounts(dry_run=False)
    )

    if acc_status != 200:
        await update.message.reply_text(f"Lỗi lấy tài khoản:\n{acc_body}",
            disable_notification=True                             
    )
        return

    if isinstance(acc_body, str):
        acc_body = json.loads(acc_body)

    investor_name = acc_body.get("name", "Không rõ")
    accounts = acc_body.get("accounts", [])

    if not accounts:
        await update.message.reply_text("Không có tài khoản.",
            disable_notification=True                                
    )
        return

    account_no = accounts[0]["id"]
    


    await update.message.reply_text(
        f"🎉 Xác thực thành công!\n\n"
        f"👤 Nhà đầu tư: {investor_name}\n"
        f"💳 Tài khoản: {account_no}\n"
        f"⏱️ Token hiệu lực 8 giờ\n",
        disable_notification=True    #thông báo im lặng True là tắt, False là bật
    )



    # ================= Kiểm tra xác thực =================

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global account_no, trading_token, current_otp_type

    global account_no, trading_token, current_otp_type, WATCHER_ENABLED

    raw = update.message.text.strip()
    text_str = unidecode(raw).upper()
    tokens = text_str.split()



    

    raw = update.message.text.strip()
    text_str = unidecode(raw).upper()
    tokens = text_str.split()

    # ===== BẬT / TẮT THÔNG BÁO =====
    if text_str in ["BAT THONG BAO", "BAT THONGBAO"]:
        WATCHER_ENABLED = True
        await update.message.reply_text("🔔 ĐÃ BẬT thông báo khớp lệnh")
        return

    if text_str in ["TAT THONG BAO", "TAT THONGBAO"]:
        WATCHER_ENABLED = False
        await update.message.reply_text("🔕 ĐÃ TẮT thông báo khớp lệnh")
        return





    # ===== AUTO VERIFY OTP nếu nhập 6 số =====
    if current_otp_type and raw.isdigit() and len(raw) == 6:

        otp_code = raw
        loop = asyncio.get_running_loop()

        status, body = await loop.run_in_executor(
            None,
            lambda: client.create_trading_token(
                otp_type=current_otp_type,
                passcode=otp_code,
                dry_run=False
            )
        )

        if status != 200:
            await update.message.reply_text(f"❌ Nhập mã OTP sai:\n",
            disable_notification=True                                
        )
            return

        if isinstance(body, str):
            body = json.loads(body)

        trading_token = body.get("tradingToken")
        client.trading_token = trading_token

        acc_status, acc_body = await loop.run_in_executor(
            None,
            lambda: client.get_accounts(dry_run=False)
        )

        if isinstance(acc_body, str):
            acc_body = json.loads(acc_body)

        investor_name = acc_body.get("name", "Không rõ")
        accounts = acc_body.get("accounts", [])

        if not accounts:
            await update.message.reply_text("Không có tài khoản.",
                disable_notification=True    #thông báo im lặng True là tắt, False là bật                                
        )
            return

        account_no = accounts[0]["id"]

        await update.message.reply_text(
            f"🎉 Xác thực thành công!\n\n"
            f"👤 Nhà đầu tư: {investor_name}\n"
            f"💳 Tài khoản: {account_no}\n"
            f"⏱️ Token hiệu lực 8 giờ",
            disable_notification=True    #thông báo im lặng True là tắt, False là bật
        )

        return
    


    # ===== Sau khi đã xác thực =====
    if account_no is None:
        await update.message.reply_text("⚠️ Chưa xác thực. Dùng /otp_email hoặc /otp_smart",
            disable_notification=True
        )
        return

    text = unidecode(raw).upper().split()

    if len(text) == 0:
        return
    
    text_str = unidecode(raw).upper()
    tokens = text_str.split()


    # ===== Thông tin tiền =====
    if text_str.startswith(("TAI", "TAI SAN TIEN")):

        loop = asyncio.get_running_loop()

        status, body = await loop.run_in_executor(
            None,
            lambda: client.get_balances(
                account_no=account_no,
                dry_run=False
            )
        )

        if status != 200:
            await update.message.reply_text(f"Lỗi thông tin tiền:\n{body}",
                disable_notification=True    #thông báo im lặng True là tắt, False là bật                            
        )
            return
        
        
        if isinstance(body, str):
            body = json.loads(body)

        stock = body.get("stock", {})
        derivative = body.get("derivative", {})

        # ===== LẤY GIÁ TRỊ CỔ PHIẾU HIỆN TẠI =====
        status_d, body_d = await loop.run_in_executor(
            None,
            lambda: client.get_deals(
                account_no=account_no,
                market_type="STOCK",
                dry_run=False
            )
        )

        total_stock_value = 0

        if status_d == 200:
            if isinstance(body_d, str):
                body_d = json.loads(body_d)

            deals = body_d.get("deals", [])

            for d in deals:
                qty = d.get("openQuantity", 0)
                price = d.get("marketPrice", 0)
                total_stock_value += qty * price

            total_cash = stock.get("totalCash", 0)
            net_asset = total_cash + total_stock_value



        def fmt(value):
            return f"{value:,.0f}" if isinstance(value, (int, float)) else "0"

        msg = "💰 THÔNG TIN TIỀN\n\n"

        msg += "🏦 --- CƠ SỞ (STOCK) ---\n\n"

        msg += (
            f"🏦 Tài sản ròng (NAV): {fmt(net_asset)}\n"
            f"💵 Tổng tiền hiện có: {fmt(stock.get('totalCash',0))}\n"
            f"💰 Tiền mặt khả dụng: {fmt(stock.get('availableCash',0))}\n"
            f"📤 Số tiền có thể rút: {fmt(stock.get('withdrawableCash',0))}\n"
            f"📊 Giá trị cổ phiếu hiện tại: {fmt(total_stock_value)}\n"
            f"🏦 Tổng nợ: {fmt(stock.get('totalDebt',0))}\n"
            f"💳 Phí lưu ký: {fmt(stock.get('depositFeeAmount',0))}\n"
            f"📈 Lãi tiền gửi: {fmt(stock.get('depositInterest',0))}\n"
 #           f"💳 Nợ margin: {fmt(stock.get('marginDebt',0))}\n"
 #           f"⏳ Tiền chờ về: {fmt(stock.get('receivingAmount',0))}\n"
 #          f"🔒 Tiền mua khớp trong ngày: {fmt(stock.get('secureAmount',0))}\n"
            f"🎁 Cổ tức chờ về: {fmt(stock.get('cashDividendReceiving',0))}\n"
        )

        #msg += "\n📈 --- PHÁI SINH (DERIVATIVE) ---\n\n"

      #  msg += (
       #     f"💰 Ký quỹ còn lại: {fmt(derivative.get('remainSecure',0))}\n"
        #    f"📌 Ký quỹ đã sử dụng: {fmt(derivative.get('usedSecure',0))}\n"
         #   f"⏳ Ký quỹ chờ xử lý: {fmt(derivative.get('pendingSecure',0))}\n"
          #  f"💵 Thuế & phí giữ lại: {fmt(derivative.get('holdTaxAndFee',0))}\n"
          #  f"💳 Tổng nợ vay: {fmt(derivative.get('totalLoanDebt',0))}\n"
            #f"🔄 Nạp/rút chờ xử lý: {fmt(derivative.get('pendingDepositWithdraw',0))}\n",
            #disable_notification=True    #thông báo im lặng True là tắt, False là bật
       # )

        await update.message.reply_text(
            msg,
            disable_notification=True                           
        )
        return

    
     # ===== DANH MỤC / GÕ TRỰC TIẾP MÃ =====

    raw = update.message.text.strip()
    text_raw = raw.split()
    text = unidecode(raw).upper().split()


    #if text[0] in ["DANH", "DANHMUC", "DANH MUC"] or (
     #   len(text) == 1 and text[0].isalpha()
    #):
    if text[0] in ["DANH", "DANHMUC", "DANH MUC"]:


    # ===== LẤY DANH SÁCH DEAL =====
        status, body = client.get_deals(
            account_no=account_no,
            market_type="STOCK",
            dry_run=False
        )

        if status != 200:
            await update.message.reply_text("❌ Lỗi lấy danh mục.",
                disable_notification=True                        
        )
            return

        if isinstance(body, str):
            body = json.loads(body)

        deals = body.get("deals", [])

        if not deals:
            await update.message.reply_text("📊 Danh mục trống.",
                disable_notification=True                          
            )
            return

    # ===== XÁC ĐỊNH CÓ LỌC MÃ KHÔNG =====
        filter_symbol = None

    # Trường hợp: DANH MUC HSG
        if len(text) >= 3:
            filter_symbol = text[2].upper()

    # Trường hợp: HSG (gõ trực tiếp)
        elif len(text) == 1 and text[0] not in ["DANH"]:
            filter_symbol = text[0].upper()

        msg = "📊 DANH MỤC NẮM GIỮ\n\n"
        found = False

        total_initial_value = 0
        total_current_value = 0
        total_profit = 0

        for s in deals:
            if not isinstance(s, dict):
                continue

            symbol = s.get("symbol", "").upper()
            quantity = s.get("openQuantity", 0)

        # Bỏ qua nếu không còn nắm giữ
            if quantity <= 0:
                continue

            if filter_symbol and symbol != filter_symbol:
                continue

            found = True

            break_price = float(s.get("breakEvenPrice", 0))
            market_price = float(s.get("marketPrice", 0))
            
            break_price_int = int(round(break_price))
            initial_value = break_price_int * quantity
            current_value = market_price * quantity


            market_price_int = int(round(market_price))
            profit = (market_price_int - break_price_int) * quantity

            total_initial_value += initial_value
            total_current_value += current_value
            total_profit += profit



            percent = 0
            if break_price > 0:
                percent = ((market_price - break_price) / break_price) * 100


            msg += (
                f"Mã: {symbol}\n"
                f"KL: {quantity}\n"
                f"Giá vốn: {break_price:,.0f}\n"
                f"Giá hiện tại: {market_price:,.0f}\n"
                f"💰 Giá trị ban đầu: {initial_value:,.0f}\n"
                f"💵 Giá trị hiện tại: {current_value:,.0f}\n"
                f"📈 Lãi/Lỗ tạm tính: {profit:,.0f} ({percent:+.2f}%)\n"
                f"----------------------\n"
            )
            


        if not found:
            await update.message.reply_text("Không có cổ phiếu nào.",
                disable_notification=True                           
            )
            return
        
        # ===== HIỂN THỊ TỔNG CHỈ KHI KHÔNG LỌC MÃ =====
        if not filter_symbol:

            total_percent = 0
            if total_initial_value > 0:
                total_percent = (total_profit / total_initial_value) * 100

            msg += (
                "========================\n"
                f"🧾 Tổng vốn: {total_initial_value:,.0f}\n"
                f"📊 Giá trị thị trường: {total_current_value:,.0f}\n"
                f"📈 Lãi/Lỗ danh mục: {total_profit:,.0f} ({total_percent:+.2f}%)\n"
            )



        await safe_send(
            update, 
            msg,
            disable_notification=True 
        )
        return
    
    

    raw = update.message.text.strip()
    text = unidecode(raw).upper().split()

       # ===== GÓI VAY / MARGIN =====
    if len(text) >= 2 and text[0] in ["GOI", "MARGIN"]:

        symbol = text[-1]   # lấy từ cuối cùng (HPG)

        loop = asyncio.get_running_loop()

        status, body = await loop.run_in_executor(
            None,
            lambda: client.get_loan_packages(
                account_no=account_no,
                market_type="STOCK",
                symbol=symbol,
                dry_run=False
            )
        )

        if status != 200:
            await update.message.reply_text(f"❌ Lỗi lấy gói vay:\n{body}",
                disable_notification=True                            
        )
            return

        if isinstance(body, str):
            body = json.loads(body)

        packages = body.get("loanPackages", [])

        if not packages:
            await update.message.reply_text(f"Không có gói vay cho {symbol}.",
                disable_notification=True                           
        )
            return

        msg = f"📦 GÓI VAY MARGIN {symbol.upper()}\n\n"

        for p in packages:

            loan_id = p.get("id")
            name = p.get("name", "").strip()

            initial_rate = p.get("initialRate", 0)  # ví dụ 0.5
            interest_rate = p.get("interestRate", 0)  # ví dụ 0.0999

            # Tỷ lệ vay = 1 - initialRate
            loan_rate = (1 - initial_rate) * 100

            msg += f"ID: {loan_id}\n"
            msg += f"Tên: {name}\n"
            msg += f"----------\n"
         # Nếu là gói margin (initialRate < 1)
        if initial_rate < 1:
            msg += f"Tỷ lệ vay: {loan_rate:.0f}%\n"
            msg += f"Lãi suất: {interest_rate*100:.2f}%\n"

        msg += "\n"


        await update.message.reply_text(
            msg,
            disable_notification=True 
        )
        return

         # ===== SỔ LỆNH =====
    if text[:2] == ["SO", "LENH"]:

        loop = asyncio.get_running_loop()

        status, body = await loop.run_in_executor(
            None,
            lambda: client.get_orders(
                account_no=account_no,
                market_type="STOCK",
                dry_run=False
            )
        )

        if status != 200:
            await update.message.reply_text(f"Lỗi lấy sổ lệnh:\n{body}")
            return

        if isinstance(body, str):
            body = json.loads(body)

        orders = body.get("orders", [])

        if not orders:
            await update.message.reply_text("📒 Không có lệnh nào.",
                disable_notification=True                             
            )
            return

        # Lọc theo mã nếu có
        filter_symbol = None
        if len(text) == 3:
            filter_symbol = text[2].upper()

        from datetime import datetime, timedelta

        msg = "📒 SỔ LỆNH\n\n"
        total_order_value = 0
        found = False

        for o in orders:

            if not isinstance(o, dict):
                continue

            symbol = o.get("symbol", "").upper()

            if filter_symbol and symbol != filter_symbol:
                continue

            found = True

            side = o.get("side", "")
            if side == "NB":
                 side_text = "🟢 Lệnh mua"
            elif side == "NS":
                side_text = "🔴 Lệnh bán"
            else:
                side_text = f"❓ {side}"

            status_map = {
                "Pending": "🟡 Lệnh được tạo",
                "PendingNew": "🟡 Chờ gửi",
                "New": "🟠 Chờ khớp",
                "PartiallyFilled": "🟡 Khớp một phần",
                "Filled": "🟢 Khớp toàn bộ",
                "Rejected": "🔴 Bị từ chối",
                "Canceled": "⚫ Đã hủy",
                "Expired": "⏳ Hết hạn trong phiên",
                "PendingCancel": "⏳ Lệnh chờ hủy",
                "PendingReplace": "🟣 Lệnh chờ sửa",
                "DoneForDay": "🔵 Lệnh được giải tỏa"
            }

            status_text = status_map.get(o.get("orderStatus"), o.get("orderStatus"))

            price = o.get("price", 0)
            quantity = o.get("quantity", 0)
            order_value = price * quantity
            total_order_value += order_value

            # ===== Giờ VN =====
            created_time = o.get("createdDate")
            if created_time:
                try:
                    dt = datetime.strptime(created_time.split(".")[0], "%Y-%m-%dT%H:%M:%S")
                    dt_vn = dt + timedelta(hours=7)
                    time_part = dt_vn.strftime("%H:%M:%S")
                except:
                    time_part = "Không rõ"
            else:
                time_part = "Không rõ"

            msg += (
                f"{side_text}\n"
                f"🆔 ID: {o.get('id')}\n"
                f"📌 Mã: {symbol}\n"
                f"📍 Trạng thái: {status_text}\n"
                f"💰 Giá đặt: {price:,.0f}\n"
                f"📦 KL đặt: {quantity}\n"
                f"✅ KL khớp: {o.get('fillQuantity',0)}\n"
                f"❌ KL hủy: {o.get('canceledQuantity',0)}\n"
                f"📌 KL còn lại: {o.get('leaveQuantity',0)}\n"
                f"💵 Giá trị lệnh: {order_value:,.0f}\n"
                f"⏰ Thời gian: {time_part}\n"
                f"--------------------------\n"
            )

        if not found:
            await update.message.reply_text("Không tìm thấy mã trong sổ lệnh.",
                disable_notification=True                             
        )
            return

        await safe_send(
            update, 
            msg,
            disable_notification=True 
        )
        return


    # ================= CHI TIẾT LỆNH =================
    if (
        text[0] == "CHI"
        or raw.lower().startswith("chi tiet")
    ):

        filter_symbol = None

        clean_text = unidecode(raw).upper()
        parts = clean_text.split()

        if len(parts) >= 3:
            # Nếu cuối cùng là mã cổ phiếu
            last_word = parts[-1]
            if last_word not in ["CHI", "TIET", "LENH"]:
                filter_symbol = last_word

        loop = asyncio.get_running_loop()

        status, body = await loop.run_in_executor(
            None,
            lambda: client.get_orders(
                account_no=account_no,
                market_type="STOCK",
                dry_run=False
            )
        )

        if status != 200:
            await update.message.reply_text(f"❌ Lỗi lấy dữ liệu.\n{body}")
            return

        if isinstance(body, str):
            body = json.loads(body)

        orders = body.get("orders", [])

        if not orders:
            await update.message.reply_text("Không có chi tiết lệnh nào.",
                disable_notification=True                               
        )
            return

        msg = "📑 CHI TIẾT LỆNH\n\n"
        found = False

        for o in orders:

            symbol = o.get("symbol", "").upper()

            if filter_symbol and symbol != filter_symbol:
                continue

            found = True

            side = o.get("side", "")
            if side == "NB":
                 side_text = "🟢 Lệnh mua"
            elif side == "NS":
                side_text = "🔴 Lệnh bán"
            else:
                side_text = f"❓ {side}"


            price = o.get("price", 0)
            quantity = o.get("quantity", 0)
            value = price * quantity

            created_time = o.get("createdDate", "")
            time_only = ""
            if "T" in created_time:
                time_only = created_time.split("T")[1][:8]

            status_raw = o.get("orderStatus", "")

            status_map = {
                "Pending": "🟡 Lệnh được tạo",
                "PendingNew": "🟡 Chờ gửi",
                "New": "🟠 Chờ khớp",
                "PartiallyFilled": "🟡 Khớp một phần",
                "Filled": "🟢 Khớp toàn bộ",
                "Rejected": "🔴 Bị từ chối",
                "Canceled": "⚫ Đã hủy",
                "Expired": "⏳ Hết hạn trong phiên",
                "PendingCancel": "⏳ Lệnh chờ hủy",
                "PendingReplace": "🟣 Lệnh chờ sửa",
                "DoneForDay": "🔵 Lệnh được giải tỏa"
            }

            status_text = status_map.get(status_raw, status_raw)


            msg += (
                f"🆔 ID: {o.get('id')}\n"
                f"{side_text}\n"
                f"📌 Mã: {symbol}\n"
                f"🏦 Tài khoản: {o.get('accountNo')}\n"
                f"📄 Loại lệnh: {o.get('orderType')}\n"
                f"📊 Trạng thái: {status_text}\n"
                f"\n"
                f"💰 Giá đặt: {o.get('price', 0):,.0f}\n"
                f"🔒 Giá Secure: {o.get('priceSecure', 0):,.0f}\n"
                f"📦 KL đặt: {o.get('quantity', 0)}\n"
                f"📈 KL khớp: {o.get('fillQuantity', 0)}\n"
                f"📉 KL hủy: {o.get('canceledQuantity', 0)}\n"
                f"📊 KL còn lại: {o.get('leaveQuantity', 0)}\n"
                f"\n"
                f"📊 Giá khớp TB: {o.get('averagePrice', 0):,.0f}\n"
                f"📌 KL khớp gần nhất: {o.get('lastQuantity', 0)}\n"
                f"📌 Giá khớp gần nhất: {o.get('lastPrice', 0):,.0f}\n"
                f"\n"
                f"💵 Giá trị lệnh: {(o.get('price', 0) * o.get('quantity', 0)):,.0f}\n"
                f"💲 Thuế: {o.get('taxRate', 0)}\n"
                f"🏛 Phí sàn: {o.get('exchangeFeeRate', 0)}\n"
                f"💰 Phí giao dịch: {o.get('feeRate', 0)}\n"
                f"\n"
                f"📆 Ngày GD: {o.get('transDate')}\n"
                f"⏰ Giờ tạo: {o.get('createdDate', '').split('T')[1][:8] if 'T' in o.get('createdDate','') else ''}\n"
                f"⏰ Giờ sửa: {o.get('modifiedDate', '').split('T')[1][:8] if 'T' in o.get('modifiedDate','') else ''}\n"
                f"\n"
                f"🏦 LoanPackageID: {o.get('loanPackageId')}\n"
                f"⚠️ Lỗi: {o.get('error')}\n"
                f"📝 Metadata: {o.get('metadata')}\n"
                f"----------------------\n"
            )

        if not found:
            await update.message.reply_text("Không có lệnh nào.",
                disable_notification=True                             
            )
            return

        await safe_send(
            update,
            msg,
            disable_notification=True 
        )
        return
    
    
    # =========================
    # Lệnh MUA / BÁN
    # =========================
    if tokens and tokens[0] in ["MUA", "BUY", "BAN", "SELL"]:

        side = "NB" if tokens[0] in ["MUA", "BUY"] else "NS"
        loop = asyncio.get_running_loop()

        # =========================
        # XÁC ĐỊNH BÁN HẾT
        # =========================
        sell_all = "HET" in [t.upper() for t in tokens]

        
        
        # =========================
        # LẤY SYMBOL (TỰ ĐỘNG TÌM)
        # =========================

        symbol = None

        for t in tokens:
            t_clean = t.strip().upper()

        # bỏ các từ lệnh
            if t_clean in ["MUA","BAN","BUY","SELL","HET","BANG","MOI","GIA","MTL","ATO","ATC"]:
                continue

            if re.match(r"^[A-Z0-9]{2,15}$", t_clean):
                symbol = t_clean
                break

        if not symbol:
            await update.message.reply_text("❌ Không tìm thấy mã cổ phiếu.",
                disable_notification=True                                      
            )
            return

        if not re.match(r"^[A-Z0-9]{2,15}$", symbol):
            await update.message.reply_text("❌ Mã chứng khoán không hợp lệ.",
                disable_notification=True                             
            )
            return

        
        # =========================
        # LẤY PHẦN SAU SYMBOL
        # =========================
        after_symbol = text_str.upper().split(symbol.upper(), 1)[-1].strip()
        numbers = re.findall(r"\d+\.?\d*", after_symbol)

        price = None
        quantity = None

        
        # ===== XÁC ĐỊNH LOẠI LỆNH =====
        if "ATO" in tokens:
            order_type = "ATO"
            price = 0
        elif "ATC" in tokens:
            order_type = "ATC"
            price = 0
        elif "MTL" in tokens or "MOI GIA" in text_str:
            order_type = "MTL"
            price = 0
        else:
            order_type = "LO"

        # =========================
        # XÁC ĐỊNH GIÁ + KHỐI LƯỢNG
        # =========================
        if not sell_all:

            # ===== LO cần giá + khối lượng =====
            if order_type == "LO":

                if len(numbers) >= 2:

                    raw_price = numbers[0]
                    raw_qty = numbers[1]

                    if "." in raw_price:
                        price = int(float(raw_price) * 1000)
                    else:
                        price = int(raw_price)

                    quantity = int(raw_qty)

                else:
                    await update.message.reply_text("❌ Sai cú pháp. Ví dụ: MUA HPG 25.5 1000",
                        disable_notification=True                             
                    )
                    return

            # ===== ATO / ATC / MTL chỉ cần khối lượng =====
            else:

                if len(numbers) >= 1:
                    quantity = int(numbers[-1])
                    price = 0
                else:
                    await update.message.reply_text("❌ Thiếu khối lượng.",
                        disable_notification=True                            
                    )
                    return

        # =========================
        # BÁN HẾT → LẤY OPEN QUANTITY
        # =========================
        if side == "NS" and sell_all:
            
            # 🔥 XÁC ĐỊNH THỊ TRƯỜNG
            status_d, body_d = await loop.run_in_executor(
                None,
                lambda: client.get_deals(
                    account_no=account_no,
                    market_type="STOCK",
                    dry_run=False
                )
            )

            if isinstance(body_d, str):
                body_d = json.loads(body_d)

            deals = body_d.get("deals", [])

            quantity = 0
            for d in deals:
                
                if d.get("symbol", "").upper() == symbol.upper():
                    quantity += d.get("openQuantity", 0)

            if quantity <= 0:
                await update.message.reply_text("❌ Không có cổ phiếu để bán.",
                    disable_notification=True                             
                )
                    
                return

        if not quantity:
            await update.message.reply_text("❌ Không xác định được khối lượng.",
                disable_notification=True                             
            )
            return

        # =========================
        # LẤY GÓI VAY
        # =========================
        status_lp, body_lp = await loop.run_in_executor(
            None,
            lambda: client.get_loan_packages(
                account_no=account_no,
                market_type="STOCK",
                symbol=symbol,
                dry_run=False
            )
        )

        if isinstance(body_lp, str):
            body_lp = json.loads(body_lp)

        packages = body_lp.get("loanPackages", [])

        if not packages:
            await update.message.reply_text("❌ Không có gói vay.",
                disable_notification=True                             
            )
            return

        loan_id = packages[0]["id"]

        # =========================
        # TẠO PAYLOAD
        # =========================
        payload = {
            "accountNo": account_no,
            "symbol": symbol,
            "side": side,
            "orderType": order_type,
            "price": price,
            "quantity": quantity,
            "loanPackageId": loan_id
        }

        # ====== XÁC NHẬN 2 BƯỚC ======
        user_id = update.effective_user.id
        if "pending_orders" not in context.bot_data:
            context.bot_data["pending_orders"] = {}



        context.bot_data["pending_orders"][user_id] = payload

        side_text = "🟢 MUA" if side == "NB" else "🔴 BÁN"

        value = price * quantity if price else 0

        # Lấy tiền khả dụng để tính %
        status_b, body_b = await loop.run_in_executor(
            None,
            lambda: client.get_balances(
                account_no=account_no,
                dry_run=False
            )
        )

        available_cash = 0
        if status_b == 200:
            if isinstance(body_b, str):
                body_b = json.loads(body_b)
            stock_info = body_b.get("stock", {})
            available_cash = stock_info.get("availableCash", 0)

        cash_percent = 0
        if available_cash > 0:
            cash_percent = (value / available_cash) * 100

            # =========================
            # KIỂM TRA ĐỦ TIỀN
            # =========================
        if side == "NB" and value > available_cash:
            await update.message.reply_text(
                f"❌ Không đủ tiền khả dụng.\n\n"
                f"💵 Tiền khả dụng: {available_cash:,.0f}\n"
                f"💎 Giá trị lệnh: {value:,.0f}",
                disable_notification=True 
            )
            return


        value = price * quantity if price else 0

       


        if order_type == "LO":
            display_price = f"{price/1000:,.2f}"
        else:
            display_price = order_type
            
        value = price * quantity if price else 0
        side_icon = "🟢" if side == "NB" else "🔴"
        side_text = "LỆNH MUA" if side == "NB" else "LỆNH BÁN"

        confirm_text = (
            f"{symbol} · HOSE\n\n"
            f"{side_icon} {side_text}\n\n"
            f"💰 Giá đặt:        {display_price}\n"
            f"📦 Khối lượng:     {quantity:,}\n"
            f"💵 Tiền mặt:       100%\n"
            f"💎 Giá trị lệnh:   {value:,}\n"
        )

        keyboard = [
            [
                InlineKeyboardButton("❌ HỦY", callback_data="cancel_order"),
                InlineKeyboardButton("✅ XÁC NHẬN", callback_data="confirm_order"),
            ]
        ]

        reply_markup = InlineKeyboardMarkup(keyboard)

        await update.message.reply_text(
            confirm_text,
            reply_markup=reply_markup,
            disable_notification=True
        )

        return
    



    
        # ===== HỦY LỆNH LINH HOẠT =====

    if text_str.lower().startswith(("huy", "hủy")):

        loop = asyncio.get_running_loop()
        cmd = text_str.lower()

        # ===== LẤY SỔ LỆNH =====
        status_o, body_o = await loop.run_in_executor(
            None,
            lambda: client.get_orders(
                account_no=account_no,
                market_type="STOCK",
                dry_run=False
            )
        )

        if status_o != 200:
            await update.message.reply_text(f"❌ Không lấy được sổ lệnh.\n{body}",
                disable_notification=True                             
            )
            return

        if isinstance(body_o, str):
           body_o = json.loads(body_o)

        orders = body_o.get("orders", [])

        # Chỉ lấy lệnh chưa khớp hết
        pending_orders = [
            o for o in orders
            if o.get("leaveQuantity", 0) > 0
        ]

        if not pending_orders:
            await update.message.reply_text("✅ Không có lệnh chờ.",
                disable_notification=True                             
            )
            return

        tokens = cmd.split()

        # ===== TRƯỜNG HỢP: HUY 123 =====
        if len(tokens) == 2 and tokens[1].isdigit():
            order_ids = [int(tokens[1])]

        # ===== TRƯỜNG HỢP: HUY TẤT CẢ =====
        elif "tat" in cmd or "tất" in cmd:
            order_ids = [o["id"] for o in pending_orders]

        # ===== TRƯỜNG HỢP: HUY HPG =====
        elif len(tokens) >= 2:
            symbol = tokens[-1].upper()

            matched = [
                o for o in pending_orders
                if o.get("symbol", "").upper() == symbol
            ]

            if not matched:
                await update.message.reply_text(f"❌ Không có lệnh chờ {symbol}.",
                    disable_notification=True                             
                )
                return

            order_ids = [o["id"] for o in matched]

        else:
            await update.message.reply_text(
                "📌 Cách hủy lệnh:\n"
                "• HUY 123\n"
                "• HUY HPG\n"
                "• HỦY LỆNH SSI\n"
                "• HỦY LỆNH TẤT CẢ",
                disable_notification=True 
            )
            return

         # ===== TIẾN HÀNH HỦY =====
        result_msg = "🛑 KẾT QUẢ HỦY LỆNH\n\n"

        for oid in order_ids:
            status_c, body_c = await loop.run_in_executor(
                None,
                lambda oid=oid: client.cancel_order(
                    account_no=account_no,
                    market_type="STOCK",
                    order_id=oid,
                    trading_token=trading_token,
                    order_category="NORMAL",
                    dry_run=False,
                )
            )

            if status_c == 200:
                result_msg += f"✅ Đã hủy lệnh ID {oid}\n"
            else:
                result_msg += f"❌ Hủy lỗi ID {oid}\n"

        await safe_send(
            update, 
            result_msg,
            disable_notification=True 
            )
        return 


   
    
    
    await update.message.reply_text("Không hiểu lệnh.",
        disable_notification=True                             
    )



async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    global trading_token

    query = update.callback_query
    await query.answer()

    user_id = query.from_user.id
    pending_orders = context.bot_data.get("pending_orders", {})
    pending = pending_orders.get(user_id)

    if query.data == "cancel_order":
        pending_orders.pop(user_id, None)
        await query.edit_message_text("❌ Đã hủy đặt lệnh.",
            disable_notification=True                           
        )
        return

    if query.data == "confirm_order":

        if not pending:
            await query.edit_message_text("⚠️ Không có lệnh chờ.",
                disable_notification=True                           
            )
            return

        loop = asyncio.get_running_loop()

        status, body = await loop.run_in_executor(
            None,
            lambda: client.post_order(
                market_type="STOCK",
                payload={
                "accountNo": account_no,
                "symbol": pending["symbol"],
                "side": pending["side"],
                "orderType": pending["orderType"],
                "price": pending["price"],
                "quantity": pending["quantity"],
                "loanPackageId": pending["loanPackageId"],
            },
            trading_token=trading_token,
            order_category="NORMAL",
            dry_run=False,
        )

        )

        pending_orders.pop(user_id, None)

        if status == 200:

            if isinstance(body, str):
                body = json.loads(body)

            order_id = body.get("id", "N/A")

            side_text = "🟢 MUA" if pending["side"] == "NB" else "🔴 BÁN"
            symbol = pending["symbol"]
            quantity = pending["quantity"]
            price = pending["price"]
            value = price * quantity if price else 0

            await query.edit_message_text(
                f"✅ ĐẶT LỆNH THÀNH CÔNG\n\n"
                f"{side_text}: {symbol}\n"
                f"📦 Khối lượng: {quantity:,}\n"
                f"💰 Giá: {price:,}\n"
                f"💵 Giá trị: {value:,}\n"
                f"🆔 ID: {order_id}"
            )

            
        else:
           # await query.edit_message_text(f"❌ Lỗi: {body}")
            
            await update.message.reply_text(
            "Dùng:\n"
            "Chưa xác thực OTP. Vui lòng lấy mã otp\n"
            "/otp_email  → nhận OTP qua email\n"
            "/otp_smart  → dùng Smart OTP trong app",
            disable_notification=True
        )
            
    
    

         #Cảnh báo lãi lỗ
async def check_profit_loss_alert(application):
    global deal_alert_state

    if account_no is None:
        return

    loop = asyncio.get_running_loop()

    status, body = await loop.run_in_executor(
        None,
        lambda: client.get_deals(
            account_no=account_no,
            market_type="STOCK",
            dry_run=False
        )
    )

    if status != 200:
        return

    if isinstance(body, str):
        body = json.loads(body)

    deals = body.get("deals", [])

    for d in deals:
        symbol = d.get("symbol")
        qty = d.get("openQuantity", 0)

        if qty <= 0:
            deal_alert_state.pop(symbol, None)
            continue

        break_price = float(d.get("breakEvenPrice", 0))
        market_price = float(d.get("marketPrice", 0))

        if break_price <= 0:
            continue

        percent = ((market_price - break_price) / break_price) * 100

        if symbol not in deal_alert_state:
            deal_alert_state[symbol] = set()

        triggered = deal_alert_state[symbol]

        # ===== CHECK LÃI =====
        for level in PROFIT_LEVELS:
            if percent >= level and level not in triggered:
                await application.bot.send_message(
                    chat_id=AUTHORIZED_CHAT_ID,
                    text=(
                        f"🚀 ĐẠT MỐC LÃI {level}%\n"
                        f"{symbol}\n"
                        f"Lãi hiện tại: {percent:.2f}%"
                    )
                )
                triggered.add(level)

        # ===== CHECK LỖ =====
        for level in LOSS_LEVELS:
            if percent <= level and level not in triggered:
                await application.bot.send_message(
                    chat_id=AUTHORIZED_CHAT_ID,
                    text=(
                        f"⚠️ CẢNH BÁO LỖ {level}%\n"
                        f"{symbol}\n"
                        f"Lỗ hiện tại: {percent:.2f}%"
                    )
                )
                triggered.add(level)


# ================= THEO DÕI KHỚP LỆNH =================
async def watch_filled_orders(application):
    print("👀 Watcher 24/7 đã chạy")

    last_state = {}

    while True:

        if not is_watcher_time():
            await asyncio.sleep(30)
            continue


        try:
            loop = asyncio.get_running_loop()

            status, body = await loop.run_in_executor(
                None,
                lambda: client.get_orders(
                    account_no=account_no,
                    market_type="STOCK",
                    dry_run=False
                )
            )

            if status != 200:
                await asyncio.sleep(2)
                continue

            if isinstance(body, str):
                body = json.loads(body)

            orders = body.get("orders", [])

            for o in orders:

                order_id = o.get("id")
                symbol = o.get("symbol")
                side = o.get("side")
                status_text = (o.get("orderStatus") or "").upper()

                quantity = o.get("quantity", 0)
                fill_qty = o.get("fillQuantity", 0)
                avg_price = o.get("averagePrice", 0)
                last_price = o.get("lastPrice", 0)
                canceled_qty = o.get("canceledQuantity", 0)

                icon = "🟢" if side == "NB" else "🔴"

                prev = last_state.get(order_id, {})
                prev_fill = prev.get("fill", 0)
                prev_status = prev.get("status")

                # ===== LẦN ĐẦU CHỈ LƯU, KHÔNG GỬI =====
                if order_id not in last_state:
                    last_state[order_id] = {
                        "fill": fill_qty,
                        "status": status_text
                    }
                    continue

                msg = None

                # ===== KHỚP THÊM =====
                if fill_qty > prev_fill:

                    if fill_qty < quantity:
                        msg = (
                            f"⚡ KHỚP THÊM\n"
                            f"{icon} {symbol}\n"
                            f"Đã khớp: {fill_qty:,}/{quantity:,}\n"
                            f"Giá khớp gần nhất: {last_price:,.0f}\n"
                            f"Giá TB: {avg_price:,.0f}"
                        )

                    elif fill_qty == quantity:
                        msg = (
                            f"🎯 KHỚP TOÀN BỘ\n"
                            f"{icon} {symbol}\n"
                            f"KL: {quantity:,}\n"
                            f"Giá TB: {avg_price:,.0f}"
                        )

                # ===== HỦY =====
                elif status_text == "CANCELED" and prev_status != "CANCELED":
                    msg = (
                        f"❌ ĐÃ HỦY LỆNH\n"
                        f"{icon} {symbol}\n"
                        f"Khớp: {fill_qty:,}\n"
                        f"Hủy: {canceled_qty:,}"
                    )

                if msg:
                    await application.bot.send_message(
                        chat_id=AUTHORIZED_CHAT_ID,
                        text=msg
                    )


                last_state[order_id] = {
                    "fill": fill_qty,
                    "status": status_text
                }

            await asyncio.sleep(2)

        except Exception as e:
            print("❌ Lỗi watcher:", e)
            await asyncio.sleep(5)








# ================= RUN BOT =================
request = HTTPXRequest(
    connect_timeout=30,
    read_timeout=30,
    write_timeout=30,
    pool_timeout=30,
)



print("🤖 Đang khởi động bot...")




async def post_init(application):

    import socket
    import platform

    # 🔔 GỬI THÔNG BÁO KHỞI ĐỘNG

   # 🕘 Thời gian VN
    now = datetime.now(VN_TZ).strftime("%d/%m/%Y %H:%M:%S")

    # 🖥 Thông tin thiết bị
    hostname = socket.gethostname()
    os_info = f"{platform.system()} {platform.release()}"
    architecture = platform.machine()

    # 🔋 RAM & CPU
    ram_percent = psutil.virtual_memory().percent
    cpu_percent = psutil.cpu_percent(interval=1)


    # 🌐 IP nội bộ
    try:
        local_ip = socket.gethostbyname(hostname)
    except:
        local_ip = "Không xác định"

    # 🌍 Lấy IP public + quốc gia + ISP
    try:
        ip_data = requests.get("http://ip-api.com/json/", timeout=5).json()
        public_ip = ip_data.get("query", "Không rõ")
        country = ip_data.get("country", "Không rõ")
        isp = ip_data.get("isp", "Không rõ")
    except:
        public_ip = "Không lấy được"
        country = "Không rõ"
        isp = "Không rõ"

    message = (
        "🚀 BOT DNSE ĐÃ KHỞI ĐỘNG\n\n"
        f"🕘 Thời gian: {now}\n"
        f"🖥 Máy: {hostname}\n"
        f"💻 Hệ điều hành: {os_info}\n"
        f"🧠 CPU: {architecture}\n"
        f"🔋 RAM đang dùng: {ram_percent}%\n"
        f"📊 CPU load: {cpu_percent}%\n"
        f"🌍 Quốc gia: {country}\n"
        f"🏢 Nhà mạng: {isp}\n"
        f"🌐 IP public: {public_ip}\n"
        f"🌍 IP nội bộ: {local_ip}\n\n"
        
    )

    await application.bot.send_message(
        chat_id=AUTHORIZED_CHAT_ID,
        text=message,
        disable_notification=False
    )

    # 👀 Khởi động watcher
    application.create_task(watch_filled_orders(application))
    print("👀 Watcher đã khởi động")

app = (
    ApplicationBuilder()
    .token(BOT_TELEGRAM)
    .request(request)
    .post_init(post_init)
    .build()
)


app.add_handler(CommandHandler("otp", request_otp))
app.add_handler(CommandHandler("otp_email", request_otp_email))
app.add_handler(CommandHandler("otp_smart", request_otp_smart))
app.add_handler(CommandHandler("verify", verify_otp))
app.add_handler(CallbackQueryHandler(button_handler))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))



print("✅ Bot đã sẵn sàng! Đang chạy...")

    
app.run_polling(
        poll_interval=0.5,
        timeout=30,
        drop_pending_updates=True
)




