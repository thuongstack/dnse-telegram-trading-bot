import asyncio
from dnse import DNSEClient
from datetime import datetime
from zoneinfo import ZoneInfo
import requests

# ====== CẤU HÌNH ======
API_KEY = "YOUR_API_KEY"
API_SECRET = "YOUR_API_SECRET"
BASE_URL = "https://openapi.dnse.com.vn"

ACCOUNT_NO = "0003979888"

TELEGRAM_TOKEN = "YOUR_TELEGRAM_TOKEN"
TELEGRAM_CHAT_ID = "YOUR_CHAT_ID"

VN_TZ = ZoneInfo("Asia/Ho_Chi_Minh")

WATCHER_DAYS = [0,1,2,3,4]
WATCHER_START = (8, 30)
WATCHER_END   = (15, 30)

# ====== DNSE CLIENT CHỈ THEO DÕI ======
client = DNSEClient(
    api_key=API_KEY,
    api_secret=API_SECRET,
    base_url=BASE_URL,
)

last_state = {}

# ======================

def is_watcher_time():
    now = datetime.now(VN_TZ)
    weekday = now.weekday()

    if weekday not in WATCHER_DAYS:
        return False

    start_time = now.replace(
        hour=WATCHER_START[0],
        minute=WATCHER_START[1],
        second=0,
        microsecond=0
    )

    end_time = now.replace(
        hour=WATCHER_END[0],
        minute=WATCHER_END[1],
        second=59,
        microsecond=999999
    )

    return start_time <= now <= end_time


def send_telegram(text):
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": text
    }
    requests.post(url, json=payload, timeout=10)


async def watch_orders():
    global last_state

    while True:
        try:
            if not is_watcher_time():
                await asyncio.sleep(5)
                continue

            status, body = client.get_orders(
                account_no=ACCOUNT_NO,
                market_type="STOCK",
                dry_run=False
            )

            if status != 200:
                await asyncio.sleep(5)
                continue

            orders = body.get("orders", [])

            for order in orders:
                order_id = order["id"]
                fill_qty = order["fillQuantity"]
                status_text = order["orderStatus"]

                prev = last_state.get(order_id, {})
                prev_fill = prev.get("fill", 0)
                prev_status = prev.get("status")

                # Có khớp thêm
                if fill_qty > prev_fill:
                    msg = (
                        f"🔔 Khớp lệnh {order['symbol']}\n"
                        f"Side: {order['side']}\n"
                        f"Giá: {order['averagePrice']}\n"
                        f"Khớp: {fill_qty}/{order['quantity']}\n"
                        f"Trạng thái: {status_text}"
                    )

                    send_telegram(msg)

                # Hủy lệnh
                if status_text == "Canceled" and prev_status != "Canceled":
                    msg = f"❌ Lệnh {order['symbol']} đã hủy"
                    send_telegram(msg)

                last_state[order_id] = {
                    "fill": fill_qty,
                    "status": status_text
                }

        except Exception as e:
            print("Watcher error:", e)

        await asyncio.sleep(3)


if __name__ == "__main__":
    asyncio.run(watch_orders())
