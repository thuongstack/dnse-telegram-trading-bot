import time
import json
import requests
from dnse import DNSEClient


# =========================
# CẤU HÌNH DNSE
# =========================
API_KEY = "your_api_key"
API_SECRET = "your_api_secret"
ACCOUNT_NO = "0001250364"

# =========================
# TELEGRAM
# =========================
TELEGRAM_TOKEN = "your_bot_token"
TELEGRAM_CHAT_ID = "your_chat_id"

# =========================
# ZALO BOT API
# =========================
ZALO_BOT_TOKEN = "your_zalo_access_token"
ZALO_CHAT_ID = "your_user_id"

# =========================
# CẢNH BÁO %
# =========================
PROFIT_LEVELS = [10, 20, 30]
LOSS_LEVELS = [-5, -10, -20]

CHECK_INTERVAL = 10  # giây

# =========================
# KHỞI TẠO
# =========================
client = DNSEClient(
    api_key=API_KEY,
    api_secret=API_SECRET,
    base_url="https://openapi.dnse.com.vn",
)

deal_alert_state = {}

# =========================
# GỬI TELEGRAM
# =========================
def send_telegram(msg):
    url = f"https://api.telegram.org/bot{TELEGRAM_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": msg
    }
    try:
        requests.post(url, json=payload, timeout=5)
    except:
        pass

# =========================
# GỬI ZALO
# =========================
def send_zalo(msg):
    url = f"https://bot-api.zaloplatforms.com/bot{ZALO_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": ZALO_CHAT_ID,
        "text": msg
    }
    try:
        requests.post(url, json=payload, timeout=5)
    except:
        pass

# =========================
# WATCHER
# =========================
print("🚀 Watch deal alert started...")

while True:
    try:
        status, body = client.get_deals(
            account_no=ACCOUNT_NO,
            market_type="STOCK",
            dry_run=False
        )

        if isinstance(body, str):
            body = json.loads(body)

        deals = body.get("deals", [])

        for d in deals:

            symbol = d.get("symbol")
            open_qty = d.get("openQuantity", 0)

            if open_qty <= 0:
                continue

            cost = d.get("costPrice", 0)
            market = d.get("marketPrice", 0)

            if cost <= 0 or market <= 0:
                continue

            percent = round(((market - cost) / cost) * 100, 2)

            last_level = deal_alert_state.get(symbol, 0)

            level_hit = None

            # ===== LÃI =====
            for lvl in PROFIT_LEVELS:
                if percent >= lvl and last_level < lvl:
                    level_hit = lvl

            # ===== LỖ =====
            for lvl in LOSS_LEVELS:
                if percent <= lvl and last_level > lvl:
                    level_hit = lvl

            if level_hit is None:
                continue

            deal_alert_state[symbol] = level_hit

            icon = "🟢" if percent > 0 else "🔴"

            msg = (
                f"{icon} CẢNH BÁO DANH MỤC\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"📌 Mã: {symbol}\n"
                f"📦 Khối lượng: {open_qty:,}\n"
                f"💰 Giá vốn: {cost:,.0f}\n"
                f"📊 Giá thị trường: {market:,.0f}\n"
                f"━━━━━━━━━━━━━━━━━━\n"
                f"📈 Lãi/Lỗ: {percent}%\n"
                f"💵 Giá trị hiện tại: {(market * open_qty):,.0f}\n"
            )

            print(msg)
            send_telegram(msg)
            send_zalo(msg)

        time.sleep(CHECK_INTERVAL)

    except Exception as e:
        print("Lỗi:", e)
        time.sleep(5)